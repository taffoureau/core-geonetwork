cd `dirname $0`
 ROOT_PATH=`pwd`
java -Xms256M -Xmx1024M -cp classpath.jar: geonetwork.loadcontactdirassubtemplate_0_1.loadContactDirAsSubTemplate --context=postgres $* 